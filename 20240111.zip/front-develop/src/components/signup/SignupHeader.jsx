const SignupHeader = () => {
  return (
    <>
      <h2>이메일 주소를 알려주세요.</h2>
      <p>입력하신 주소로 인증번호가 전송됩니다.</p>
    </>
  )
};

export default SignupHeader;