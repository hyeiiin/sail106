package com.sail.back.user.model.dto.params;

public class UserParam {
}
