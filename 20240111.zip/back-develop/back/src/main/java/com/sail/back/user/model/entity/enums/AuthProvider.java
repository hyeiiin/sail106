package com.sail.back.user.model.entity.enums;

public enum AuthProvider {
    GENERAL, NAVER, KAKAO, GOOGLE
}
