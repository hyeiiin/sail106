package com.sail.back.user.model.entity.enums;

public enum UserRole {
    USER, ADMIN, CONSULTANT
}
