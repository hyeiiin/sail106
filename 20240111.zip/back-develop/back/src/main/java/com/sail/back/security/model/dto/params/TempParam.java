package com.sail.back.security.model.dto.params;

public class TempParam {
}
