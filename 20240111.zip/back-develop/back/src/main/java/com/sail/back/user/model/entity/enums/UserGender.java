package com.sail.back.user.model.entity.enums;

public enum UserGender {
    MALE, FEMALE
}
