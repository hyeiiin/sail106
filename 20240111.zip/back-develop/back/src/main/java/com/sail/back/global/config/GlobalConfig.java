package com.sail.back.global.config;

public class GlobalConfig {
}
