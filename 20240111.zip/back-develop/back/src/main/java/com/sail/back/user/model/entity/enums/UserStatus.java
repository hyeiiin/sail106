package com.sail.back.user.model.entity.enums;

public enum UserStatus {
    ACTIVE, INACTIVE, DELETE
}
