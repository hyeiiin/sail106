package com.sail.back.security.handler;

public class OauthSuccessHandler {
}
