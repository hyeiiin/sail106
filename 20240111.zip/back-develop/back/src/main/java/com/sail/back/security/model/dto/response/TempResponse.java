package com.sail.back.security.model.dto.response;

public class TempResponse {
}
